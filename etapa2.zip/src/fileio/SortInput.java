package fileio;

public class SortInput {

    private String rating;
    private String duration;

    public SortInput() {

    }

    /** Get the rating */
    public String getRating() {
        return rating;
    }

    /** Set the rating */
    public void setRating(final String rating) {
        this.rating = rating;
    }

    /** Get the duration */
    public String getDuration() {
        return duration;
    }

    /** Set the duration */
    public void setDuration(final String duration) {
        this.duration = duration;
    }


}
